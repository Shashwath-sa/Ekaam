# EKAAM — SIH 2026 functional prototype

Prototype uses synthetic records only. No live APAAR/AICTE integration. Review actor is demo-only, NOT authenticated. Do not use real student data or deploy publicly without authentication, authorization, privacy controls and security hardening.

## Requirements
Python 3.10+ and Node.js 18+

## Backend
```bash
cd backend
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```
API: http://localhost:8000/docs

## Frontend (second terminal)
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

## Demo
Open Upload Records; choose `sample_data/students_demo.csv`; upload. Visit Dashboard, Validation & Duplicates, Review Queue, Audit Trail. On Intake Intelligence, save Demo Institution / CSE / 2026 / 2 to demonstrate over-capacity detection.

## Current limitations / next steps
- Duplicate candidates use exact APAAR match or fuzzy name+programme; this is heuristic and must be human-reviewed.
- Upload has basic limits, no login/role authorization, no official integrations, no data masking and no batch rollback controls.
- Intake reported counts include all uploaded records, including duplicates; production implementation needs deduplicated counts and policy-defined inclusion rules.
- Production should use PostgreSQL, migrations, tests, background processing, secure authentication and a privacy review.
