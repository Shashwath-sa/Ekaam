from datetime import datetime, timezone
from io import BytesIO
import re
import pandas as pd
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey, select, func
from sqlalchemy.orm import declarative_base, sessionmaker
from rapidfuzz import fuzz

engine = create_engine('sqlite:///./ekaam.db', connect_args={'check_same_thread': False})
Session = sessionmaker(bind=engine)
Base = declarative_base()

class Student(Base):
    __tablename__ = 'students'
    id = Column(Integer, primary_key=True)
    apaar_id = Column(String(30), index=True)
    name = Column(String(150))
    programme = Column(String(100))
    year = Column(Integer)
    email = Column(String(150))
    institution = Column(String(150))
    status = Column(String(30), default='pending')
    reason = Column(String(500), default='')

class Intake(Base):
    __tablename__ = 'intakes'
    id = Column(Integer, primary_key=True)
    institution = Column(String(150))
    programme = Column(String(100))
    year = Column(Integer)
    approved = Column(Integer)

class Audit(Base):
    __tablename__ = 'audit'
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey('students.id'), nullable=True)
    action = Column(String(60))
    actor = Column(String(100))
    reason = Column(String(500))
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

Base.metadata.create_all(engine)
app = FastAPI(title='EKAAM API', version='0.1')
app.add_middleware(CORSMiddleware, allow_origins=['http://localhost:5173','http://127.0.0.1:5173'], allow_methods=['*'], allow_headers=['*'])

def serialize(s):
    return {k:getattr(s,k) for k in ('id','apaar_id','name','programme','year','email','institution','status','reason')}

@app.get('/api/health')
def health(): return {'status':'ok'}

@app.get('/api/students')
def students():
    with Session() as db:
        return [serialize(s) for s in db.scalars(select(Student).order_by(Student.id.desc())).all()]

@app.get('/api/dashboard')
def dashboard():
    with Session() as db:
        rows = db.scalars(select(Student)).all()
        return {'total':len(rows),'verified':sum(s.status=='verified' for s in rows),'flagged':sum(s.status=='flagged' for s in rows),'pending':sum(s.status=='pending' for s in rows)}

@app.post('/api/upload')
async def upload(file: UploadFile = File(...), institution: str = 'Demo Institution'):
    filename = file.filename or ''
    raw = await file.read()
    if len(raw) > 5_000_000: raise HTTPException(413,'Maximum upload size is 5 MB')
    try:
        if filename.lower().endswith('.csv'): df = pd.read_csv(BytesIO(raw), dtype=str).fillna('')
        elif filename.lower().endswith('.xlsx'): df = pd.read_excel(BytesIO(raw), dtype=str).fillna('')
        else: raise HTTPException(400,'Upload a .csv or .xlsx file')
    except HTTPException: raise
    except Exception as exc: raise HTTPException(400,f'Could not read file: {exc}')
    df.columns = [str(c).strip().lower() for c in df.columns]
    required = {'apaar_id','name','programme','year','email'}
    if not required.issubset(df.columns): raise HTTPException(400,f'Missing columns: {sorted(required-set(df.columns))}')
    if len(df)>2000: raise HTTPException(400,'Maximum 2000 records per upload')
    counts = {'uploaded':0,'flagged':0,'pending':0}
    with Session() as db:
        existing = db.scalars(select(Student)).all()
        for _, r in df.iterrows():
            apaar = str(r['apaar_id']).strip(); name=str(r['name']).strip()
            programme=str(r['programme']).strip(); email=str(r['email']).strip()
            yr=str(r['year']).strip()
            reasons=[]
            if not all([apaar,name,programme,yr,email]): reasons.append('Missing mandatory field')
            if apaar and not re.fullmatch(r'\d{12}',apaar): reasons.append('APAAR ID must contain 12 digits (demo rule)')
            if email and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email): reasons.append('Invalid email')
            try: year=int(yr)
            except ValueError: year=None; reasons.append('Invalid academic year')
            if apaar and any(s.apaar_id==apaar for s in existing): reasons.append('Duplicate APAAR ID')
            elif name and any(s.name and fuzz.ratio(s.name.lower(),name.lower())>=90 and s.programme==programme for s in existing): reasons.append('Possible duplicate name and programme')
            student=Student(apaar_id=apaar,name=name,programme=programme,year=year,email=email,institution=institution,status='flagged' if reasons else 'pending',reason='; '.join(reasons))
            db.add(student); db.flush()
            db.add(Audit(student_id=student.id,action='uploaded',actor='Institution Staff',reason=student.reason or 'Awaiting verification'))
            existing.append(student)
            counts['uploaded']+=1; counts[student.status]+=1
        db.commit()
    return counts

class Decision(BaseModel):
    action: str
    reason: str
    actor: str = 'Demo Reviewer'

@app.post('/api/students/{student_id}/review')
def review(student_id: int, decision: Decision):
    if decision.action not in ('verified','rejected','correction_requested'): raise HTTPException(400,'Invalid action')
    if not decision.reason.strip(): raise HTTPException(400,'Reason required')
    with Session() as db:
        s=db.get(Student,student_id)
        if not s: raise HTTPException(404,'Student not found')
        s.status=decision.action; s.reason=decision.reason
        db.add(Audit(student_id=s.id,action=decision.action,actor=decision.actor,reason=decision.reason)); db.commit()
        return serialize(s)

@app.get('/api/audit')
def audit():
    with Session() as db:
        rows=db.scalars(select(Audit).order_by(Audit.id.desc()).limit(200)).all()
        return [{'id':a.id,'student_id':a.student_id,'action':a.action,'actor':a.actor,'reason':a.reason,'created_at':a.created_at.isoformat()} for a in rows]

class IntakeInput(BaseModel):
    institution: str
    programme: str
    year: int
    approved: int

@app.post('/api/intakes')
def set_intake(data: IntakeInput):
    if data.approved<0: raise HTTPException(400,'Approved intake cannot be negative')
    with Session() as db:
        row=db.scalar(select(Intake).where(Intake.institution==data.institution,Intake.programme==data.programme,Intake.year==data.year))
        if row: row.approved=data.approved
        else: db.add(Intake(**data.model_dump()))
        db.commit()
    return {'saved':True}

@app.get('/api/intakes')
def intakes():
    with Session() as db:
        rows=db.scalars(select(Intake)).all()
        return [{'institution':i.institution,'programme':i.programme,'year':i.year,'approved':i.approved,'reported':db.scalar(select(func.count()).select_from(Student).where(Student.institution==i.institution,Student.programme==i.programme,Student.year==i.year))} for i in rows]
